from argparse import ArgumentParser, Namespace, _SubParsersAction
from libraries.message import print_error, print_success
import webbrowser

def parse_git(subparsers: _SubParsersAction[ArgumentParser]) -> None:
  parser: ArgumentParser = subparsers.add_parser("git", help="Open source code repository in web browser.")
  parser.set_defaults(func=handle_git)

def handle_git(args: Namespace) -> None:
  print("🌐 Opening source code repository...")
  if not webbrowser.open("https://github.com/TheRake66/python-fast"):
    print_error("Can't open repository!")
  else: print_success("Successfully opened.")